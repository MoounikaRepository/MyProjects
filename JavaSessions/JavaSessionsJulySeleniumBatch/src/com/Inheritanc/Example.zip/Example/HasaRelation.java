package com.Inheritanc.Example;

public class HasaRelation {
	
	public void test123() {
		System.out.println("has a relation");
	}

}
