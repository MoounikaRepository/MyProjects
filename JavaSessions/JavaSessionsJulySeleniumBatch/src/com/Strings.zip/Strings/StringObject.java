package com.Strings;

public class StringObject {
	
	//String is immutable  in java
	//we cant change the string value in java
	
	
	public static void main(String[] args) {
		
		String s="Selenium";//string object using literal
		
		String s1=s.concat("Autiomation");
		
		System.out.println(s1);
		
	}

}
