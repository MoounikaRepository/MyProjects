package com.Encapsulation;

public class BMW extends Car {
	
	/*
	 * @Override public final void test() {
	 * 
	 * }
	 */

}
