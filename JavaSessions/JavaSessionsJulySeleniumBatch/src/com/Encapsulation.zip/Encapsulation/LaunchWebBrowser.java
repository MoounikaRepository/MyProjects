package com.Encapsulation;

public class LaunchWebBrowser {
	
	private void launchBrowser() {
		
		System.out.println("launch browser");
	}

	
	private void browserversion() {
		System.out.println("version chrome 103");
	}

	
	public void browserinfo() {
		launchBrowser();
		browserversion();
	}
}
