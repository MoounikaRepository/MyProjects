package com.Interface;

public interface IndiaMedical  extends WHO{
	
	//clas to clas ->extends
	//interface to interface-->extends
	//interface to class-->implements
	
	
	public void generalService();
	public void NuroService();

}
