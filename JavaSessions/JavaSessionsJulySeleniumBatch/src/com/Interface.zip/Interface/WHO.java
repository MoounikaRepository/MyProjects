package com.Interface;

public interface WHO {

	public void CovidTest();
	
}
